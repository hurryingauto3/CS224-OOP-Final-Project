-----Features
- Player Controlled Movement in 8 Directions
- Comes with 4 Directions Character Sprites
- Prevents Player from getting stuck on corners
?
-----Instructions
1. Download the project folder from this page.
2. Start Gamemaker Studio 2.
3. Open the .yyp file inside the project folder in Gamemaker Studio 2.
4. Get creative!?

-----Creator's Notes
?Since a long time I've been annoyed by characters that get stuck on corners by a collision of only 1 pixel. I finally found a solution I didn't expect to be so simple.

I have not tested this at great length, but  I believe this should work as intended. There might be some code for wall-glide out there that is more smooth (Especially on diagonal walls), but for starters this works fine.

-----Feedback
If you have any tips or feedback on this project, or if you have any questions or found a bug, please leave a comment. There might be ways to improve this project and I'd love to hear about them!

-----Credits
?Full project (including the pixel art) has been made by me RanDB.  Although crediting me is appreciated, it is not required. However, please do not claim any of my pixel art  as your own.?

The movement-code is the result of things I picked up from a variety of tutorials I've watched in the past. I can't exactly recall where I learned each aspect, but the tutorials of Friendly Cosmonaut? have definitely helped me out the most when I was still learning the basics of GameMaker.

https://twitter.com/RandbYyp
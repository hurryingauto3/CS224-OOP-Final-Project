#pragma once
#include <string>
#include "SDL.h"

class Collider
{
    
};
#include "Master.hpp"
class Node
{
public:
    Node *prev;
    MasterObject *data;
    Node *next;
};

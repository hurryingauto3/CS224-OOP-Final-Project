// #include "Credits.h"
// using namespace std;

// void Credits::load()
// {
//     //Create the loading progress bar using console outputs.
//     std::cout<<"\n \n \n \n \n \n \n \n \n \n \n \n";
//     std::cout<<"                                                      ";
//     std::cout<<"Loading...";
//     std::cout<<"                                                      ";
//     std::cout<<"\n \n";
//     std::cout<<"                                                ";
//     for (int i=0; i<=20; i++)
//     {
//         Sleep(80); //delay the progress bar in milliseconds
//         std::cout<<char(219);
//     }
// }

// void Credits::text()
// {
//     std::cout<<"\n \n"<<endl;
//     std::cout<<"                                  ";
//     std::cout<<"************************************************"<<std::endl;
//     std::cout<<"                                  ";
//     std::cout<<"          THANK YOU! For Playing our Game.                "<<std::endl;
//     std::cout<<"                                  ";
//     std::cout<<"************************************************"<<std::endl;
// }

// void Credits::ascii()
// {
//     std::cout<<R"(

//     __  __      __  ___               __  __      __    _ __
//    / / / /___  / /_/ (_)___  ___     / / / /___ _/ /_  (_) /_
//   / /_/ / __ \/ __/ / / __ \/ _ \   / /_/ / __ `/ __ \/ / __ \
//  / __  / /_/ / /_/ / / / / /  __/  / __  / /_/ / /_/ / / /_/ /
// /_/ /_/\____/\__/_/_/_/ /_/\___/  /_/ /_/\__,_/_.___/_/_.___/

// )"<< '\n'; //Raw string input
// }

// int main()
// {
//     Credits cred;
//     cred.load();
//     cred.text();
//     cred.ascii();
//     std::cout<<"// A project by Affan Amir Mir | Ali Hamza | Maaz Saeed | Sabah Ismail //"<<std::endl;
//     std::cout<<"\n \n \n"<<std::endl;
//     return 0;
// }

#include<iostream>
#include<string>
#include<conio.h>
#include<windows.h> //needed for sleep function
using namespace std;

class Credits
{
public:
    void load();
    void text();
    void ascii();
    void Credit();
};

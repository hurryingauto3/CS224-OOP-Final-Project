// #include "Player.h"
// #include "GameObject.h"

// #ifndef ENEMY_H
// #define ENEMY_H
// class Enemyy : public GameObject
// {
// private:
//     bool IsPlayerClosebool;

// public:
//     bool IsPlayerClose(Playerr *A);
//     void ApproachPlayer(Playerr *A);
//     bool returnclose();
//     void Path(int x1, int y, int x2, int y2, int x3, int y3, int x4, int y4);
//     Enemyy() {}
//     Enemyy(std::string Sprite, int xpos, int ypos);
//     Enemyy(std::string Sprite, int xpos, int ypos, int frames, int speed);
//     ~Enemyy();
// };

// #endif
